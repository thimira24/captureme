<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://cdn.jsdelivr.net/npm/comlinkjs@3.0.2/umd/comlink.js"></script>

    <!-- Detect browser JavaScript -->
    <script src="js/browserDetect.js"></script>

    
    <title id="titleCaption">Privacy Policy | CaptureMe Online Free Screen Recorder</title>
    <link rel="icon" type="image/x-icon" href="assets/images/logo.webp">

    <meta property="og:title" content="CaptureMe - Online Free Screen Recorder">
    <meta property="og:url" content="http://www.captureme.online/">
    <meta property="og:description" content="Now you can simply record your screen without installing any software. CaptureMe is totally free. instantly capture your meetings, lectures, presentations, games, and more. Enjoy!">
    <meta property="og:type" content="website">
    <meta property="og:image" content="assets/images/CaptureMe.png">

    <meta name="googlebot" content="notranslate"/>
    <meta name="google" content="nopagereadaloud"/>
    <meta name="google" content="nositelinkssearchbox"/>

    <meta name="author" content="captureme.online"/>
    <meta name="keywords" content="Free Online Screen Recorder - No download and install required. You can seamlessly record your screen with audio">
    <meta name="title" content="CaptureMe - Online Free Screen Recorder">
    <meta name="description" content="Now you can simply record your screen without installing any software. CaptureMe is totally free. instantly capture your meetings, lectures, presentations, games, and more. Enjoy!">


    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-FY6HB1DB7S"></script>
    
    <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'G-FY6HB1DB7S');
    </script>

    <!--    Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Inter:300,900|Ubuntu:400,700&display=swap" rel="stylesheet">
    <!--    Bootstrap css files-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--    Custom css files-->
    <link rel="stylesheet" href="assets/css/styles.css">
    
    <!--    Font Awesome-->
    <script defer src="https://kit.fontawesome.com/e87d687bba.js"></script>
    <!--    Bootstrap js files-->
    <script defer src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script defer src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

</head>

<body>

    <!-- Nav Bar -->
    <?php include 'components/header.html';?>

    <!-- privacy section -->
    <?php include 'components/privacy.html';?>

    <script data-name="BMC-Widget" data-cfasync="false" src="https://cdnjs.buymeacoffee.com/1.0.0/widget.prod.min.js" data-id="thimira" data-description="Support me on Buy me a coffee!" data-message="Thank you for visiting. Tell me how can I help you? or Buy me a cofee!" data-color="#2ee59d" data-position="Right" data-x_margin="18" data-y_margin="18"></script>

    <!-- footer section -->
    <?php include 'components/footer.html';?>
        
</body>


</html>