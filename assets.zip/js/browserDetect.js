function fnBrowserDetect() {

          let userAgent = navigator.userAgent;
          let browserName;

          if (userAgent.match(/chrome|chromium|crios/i)) {
            browserName = "chrome";
            document.getElementById("warning-message").innerText = "Supported browsers: Google Chrome, Mozilla Firefox, Microsoft Edge, Opera or Brave.";
          } else if (userAgent.match(/firefox|fxios/i)) {
            browserName = "firefox";
             document.getElementById("warning-message").innerText = "Supported browsers: Google Chrome, Mozilla Firefox, Microsoft Edge, Opera or Brave.";
          } else if (userAgent.match(/safari/i)) {
            browserName = "safari";
             document.getElementById("warning-message").innerText = "The";
          } else if (userAgent.match(/opr\//i)) {
            browserName = "opera";
             document.getElementById("warning-message").innerText = "Supported browsers: Google Chrome, Mozilla Firefox, Microsoft Edge, Opera or Brave.";
          } else if (userAgent.match(/edg/i)) {
            browserName = "edge";
             document.getElementById("warning-message").innerText = "Supported browsers: Google Chrome, Mozilla Firefox, Microsoft Edge, Opera or Brave.";
          } else {
            browserName = "No browser detection";
          }


}


 

