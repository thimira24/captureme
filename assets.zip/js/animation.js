
TweenMax.from(".product-img", 3, {
delay: 0.1,

y: 20,
ease: Expo.easeInOut
});


